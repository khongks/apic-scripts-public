
## To create a member
./my-create-member.sh "wsvnonproduser" \
                    "" \
					"firstwsvnonproduser" \
					"lastwsvnonproduser" \
					"wsvnonproduser@khongksgmail.onmicrosoft.com" \
					"azure-oidc" \
					"administrator" \
					"org" \
					"admin"


MEMBER_NAME=${1}
ROLE_NAME=${2}
LUR_NAME=${3:-"api-manager-lur"}
ORG_NAME=${4:-"IBM"}
SCOPE=${5:-"org"}
SERVER_NAME=$6

./members/create.sh "wsvnonproduser" "administrator" "azure-oidc" "admin" "org" "https://cpd-cp4i.itzroks-3100015379-w96p7r-4b4a324f027aea19c5cbc0c3275c4656-0000.us-east.containers.appdomain.cloud/integration/apis/apic/myapic"