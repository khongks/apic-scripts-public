#!/bin/bash

##
## Set your environment variables
##
. ./env.vars
. ./my-env.vars


##
## Login to API Manager
##

ORG_NAME="wsv-np"
OWNER_NAME="wsvnonproduser"
########## TODO: AWS Secret Manager ##########
OWNER_PASSWORD="Kks190571!"
PROVIDER_REALM="provider/jump-cloud"
USER_REGISTRY_NAME="jump-cloud"
./login-mgr.sh "$OWNER_NAME" "$OWNER_PASSWORD" "$PROVIDER_REALM"

echo "Clear-all tls-client-profiles"
./tls-client-profiles/clear-all.sh ${ORG_NAME} ${APIMGR_SERVER}

sleep 2

echo "Clear keystores"
./keystores/clear.sh ${ORG_NAME} ${APIMGR_SERVER}

sleep 2

echo "Clear truststores"
./truststores/clear.sh ${ORG_NAME} ${APIMGR_SERVER}