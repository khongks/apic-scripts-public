#!/bin/bash

##
## Set your environment variables
##
. ./env.vars
. ./my-env.vars
. ./my-aws-secretmanager.sh

##
## Login to API Manager
##
PROVIDER_REALM="provider/default-idp-2"
## Retrive owner creds from AWS Secret Manager
OWNER_CREDS_JSON=$(get_username_password "creds/apic/${ORG_NAME}-owner")
OWNER_NAME=$(echo ${OWNER_CREDS_JSON} | jq -r .username)
OWNER_PASSWORD=$(echo ${OWNER_CREDS_JSON} | jq -r .password)
./login-mgr.sh "${OWNER_NAME}" "${OWNER_PASSWORD}" "${PROVIDER_REALM}"

for KEYSTORE_NAME in ${KEYSTORE_NAME_LIST}; do
	##
	## Retrieve tls.key and tls.crt from AWS Secret Manager
	## Secret name: "certs/apic/${ORG_NAME}-${KEY_STORE_NAME}"
	## 
	get_keystore_certkey "certs/apic/${ORG_NAME}-${KEY_STORE_NAME}"
	KEYSTORE_KEY_FILE="tls.key"
	KEYSTORE_CERT_FILE="tls.crt"
	##
	## Create Keystore
	##
	./keystores/get.sh "${KEYSTORE_NAME}" "${ORG_NAME}" "${CLOUD_ADMIN_SERVER}" > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		./keystores/update.sh "${KEYSTORE_NAME}" "${KEYSTORE_KEY_FILE}" "${KEYSTORE_CERT_FILE}" "${ORG_NAME}" "${APIMGR_SERVER}"
	else
		./keystores/create.sh "${KEYSTORE_NAME}" "${KEYSTORE_KEY_FILE}" "${KEYSTORE_CERT_FILE}" "${ORG_NAME}" "${APIMGR_SERVER}"
	fi
done

for TRUSTSTORE_NAME in $TRUSTSTORE_NAME_LIST; do
	##
	## Retrieve certificate chain from AWS Secret Manager
	## Secret name: "certs/apic/${ORG_NAME}-${TRUSTSTORE_NAME}"
	##
	TRUSTED_CERT_NAME_LIST="cert0 cert1 cert2"
	get_truststore_certs "certs/apic/${ORG_NAME}-${TRUSTSTORE_NAME}" "${TRUSTED_CERT_NAME_LIST}"
	TRUSTSTORE_CERT_FILE="combined-cert-chain.pem"

	##
	## Create or recreate Truststore
	##
	./truststores/get.sh "${TRUSTSTORE_NAME}" "${ORG_NAME}" "${APIMGR_SERVER}" > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		./truststores/update.sh "${TRUSTSTORE_NAME}" "${TRUSTSTORE_CERT_FILE}" "${ORG_NAME}" "${APIMGR_SERVER}"
		#./truststores/delete.sh "${TRUSTSTORE_NAME}" ${ORG_NAME} "${APIMGR_SERVER}"
	else
	    ./truststores/create.sh "${TRUSTSTORE_NAME}" "${TRUSTSTORE_CERT_FILE}" "${ORG_NAME}" "${APIMGR_SERVER}"
	fi
done

TLS_CLIENT_PROFILE_NAME_ARRAYLIST=($TLS_CLIENT_PROFILE_NAME_LIST)
TLS_CLIENT_PROFILE_VERSION_ARRAYLIST=($TLS_CLIENT_PROFILE_VERSION_LIST)
TLS_CLIENT_PROFILE_KEYSTORE_NAME_ARRAYLIST=($KEYSTORE_NAME_LIST)
TLS_CLIENT_PROFILE_TRUSTSTORE_NAME_ARRAYLIST=($TRUSTSTORE_NAME_LIST)

index=0
for TLS_CLIENT_PROFILE_NAME in "${TLS_CLIENT_PROFILE_NAME_ARRAYLIST[@]}"; do

	VERSION="${TLS_CLIENT_PROFILE_VERSION_ARRAYLIST[index]}"
	KEYSTORE_NAME="${TLS_CLIENT_PROFILE_KEYSTORE_NAME_ARRAYLIST[index]}"
	TRUSTSTORE_NAME="${TLS_CLIENT_PROFILE_TRUSTSTORE_NAME_ARRAYLIST[index]}"
	echo "$TLS_CLIENT_PROFILE_NAME:$VERSION $KEYSTORE_NAME $TRUSTSTORE_NAME"
	if [ $KEYSTORE_NAME = "none" ]; then
		KEYSTORE_NAME=""
	fi
	if [ $TRUSTSTORE_NAME = "none" ]; then
		TRUSTSTORE_NAME=""
	fi
	./tls-client-profiles/get.sh "${TLS_CLIENT_PROFILE_NAME}" "${VERSION}" "${ORG_NAME}" "${APIMGR_SERVER}" > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		./tls-client-profiles/update.sh "${TLS_CLIENT_PROFILE_NAME}" "${VERSION}" "${KEYSTORE_NAME}" "${TRUSTSTORE_NAME}" "${ORG_NAME}" "${APIMGR_SERVER}"
	else
		./tls-client-profiles/create.sh "${TLS_CLIENT_PROFILE_NAME}" "${VERSION}" "${KEYSTORE_NAME}" "${TRUSTSTORE_NAME}" "${ORG_NAME}" "${APIMGR_SERVER}"
	fi
	((++index))

done