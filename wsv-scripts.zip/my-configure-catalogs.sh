#!/bin/bash

##
## Set your environment variables
##
. ./env.vars
. ./my-env.vars
. ./my-aws-secretmanager.sh


USER_REGISTRY_NAME_SLUGIFIED=$(echo ${USER_REGISTRY_NAME} | slugify)

##
## Login to API Manager
##
PROVIDER_REALM="provider/default-idp-2"
OWNER_CREDS_JSON=$(get_username_password "creds/apic/${ORG_NAME}-owner")
OWNER_NAME=$(echo ${OWNER_CREDS_JSON} | jq -r .username)
OWNER_PASSWORD=$(echo ${OWNER_CREDS_JSON} | jq -r .password)
./login-mgr.sh "${OWNER_NAME}" "${OWNER_PASSWORD}" "${PROVIDER_REALM}"

for CATALOG_NAME in ${CATALOG_NAME_LIST}; do

	##
	## Create catalog
	## 
	LUR_NAME="api-manager-lur"
	./catalogs/get.sh "${CATALOG_NAME}" "${ORG_NAME}" > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "Catalog [${CATALOG_NAME}] already exist."
	else
		echo "Create catalog [${CATALOG_NAME}] in organization [${ORG_NAME}]"
		./catalogs/create.sh "${ORG_NAME}" "${CATALOG_NAME}" "${OWNER_NAME}" "${LUR_NAME}"
	fi

	##
	## Configure user registry for catalog
	##
	./configured-catalog-user-registries/get.sh "${USER_REGISTRY_NAME_SLUGIFIED}" "${CATALOG_NAME}" "${ORG_NAME}" "${APIMGR_SERVER}" > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "Already configured catalog user registry [${USER_REGISTRY_NAME_SLUGIFIED}]"
	else
		echo "Create configured catalog user registry [${USER_REGISTRY_NAME_SLUGIFIED}] in catalog [${CATALOG_NAME}] in organization [${ORG_NAME}]"
		./configured-catalog-user-registries/create.sh "${USER_REGISTRY_NAME_SLUGIFIED}" "${CATALOG_NAME}" "${ORG_NAME}" "${APIMGR_SERVER}"
	fi

	##
	## Configure TLS client profile for catalog
	##
	TLS_CLIENT_PROFILE_NAME="${CATALOG_NAME}-tls-client-profile"
	TLS_CLIENT_PROFILE_VERSION="1.0.0"
	SCOPE="catalog"
	./configured-tls-client-profiles/get.sh "${TLS_CLIENT_PROFILE_NAME}" "${TLS_CLIENT_PROFILE_VERSION}" "${CATALOG_NAME}" "${ORG_NAME}" "${SCOPE}" "${APIMGR_SERVER}" > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "Delete configured TLS client profile [${TLS_CLIENT_PROFILE_NAME}:${TLS_CLIENT_PROFILE_VERSION}]"
		./configured-tls-client-profiles/delete.sh ${TLS_CLIENT_PROFILE_NAME} ${TLS_CLIENT_PROFILE_VERSION} ${CATALOG_NAME} ${ORG_NAME} ${SCOPE} "${APIMGR_SERVER}"
		echo "Recreate configured tls client profile [${TLS_CLIENT_PROFILE_NAME}:${TLS_CLIENT_PROFILE_VERSION}] in catalog [${CATALOG_NAME}] in organization [${ORG_NAME}]"
		./configured-tls-client-profiles/create.sh "${TLS_CLIENT_PROFILE_NAME}" "${TLS_CLIENT_PROFILE_VERSION}" "${CATALOG_NAME}" "${ORG_NAME}" "${SCOPE}" "${APIMGR_SERVER}"
	else
		echo "Create configured tls client profile [${TLS_CLIENT_PROFILE_NAME}:${TLS_CLIENT_PROFILE_VERSION}] in catalog [${CATALOG_NAME}] in organization [${ORG_NAME}]"
		./configured-tls-client-profiles/create.sh "${TLS_CLIENT_PROFILE_NAME}" "${TLS_CLIENT_PROFILE_VERSION}" "${CATALOG_NAME}" "${ORG_NAME}" "${SCOPE}" "${APIMGR_SERVER}"
	fi

	##
	## Configure gateway service for catalog
	## 
	
	## GATEWAY_SERVICE_NAME="api-gateway-service"
	## Worksafe - it will be ${CATALOG_NAME}-api-gateway-service
	./configured-gateway-services/get.sh ${GATEWAY_SERVICE_NAME} ${CATALOG_NAME} ${ORG_NAME} "org" > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "Already configured gateway service [${GATEWAY_SERVICE_NAME}]"
	else 
		echo "Create configured gateway service [${GATEWAY_SERVICE_NAME}] in catalog [${CATALOG_NAME}] in organization [${ORG_NAME}]"
		./configured-gateway-services/create.sh ${GATEWAY_SERVICE_NAME} ${CATALOG_NAME} ${ORG_NAME}
	fi

	##
	## Enable portal 
	## 
	./catalog-settings/create-portal.sh ${CATALOG_NAME} ${ORG_NAME} ${PORTAL_SERVICE_NAME}

	## 
	## Add vanity api endpoints
	## 
	API_ENDPOINT_1="https://api-${CATALOG_NAME}.${API_ENDPOINT_DOMAIN}/${ORG_NAME}/${CATALOG_NAME}"
	API_ENDPOINT_2="https://apigw-${CATALOG_NAME}.np.${API_ENDPOINT_DOMAIN}/${ORG_NAME}/${CATALOG_NAME}"

    API_ENDPOINTS="{\"endpoint\": \"${API_ENDPOINT_1}\",\"description\": \"Vanity endpoint for ${GATEWAY_SERVICE_NAME} in ${CATALOG_NAME}\",\"type\": [\"production\",\"development\"]}"
    API_ENDPOINTS=${API_ENDPOINTS}",{\"endpoint\": \"${API_ENDPOINT_2}\",\"description\": \"Vanity endpoint for ${GATEWAY_SERVICE_NAME} in ${CATALOG_NAME}\",\"type\": [\"production\",\"development\"]}"
	echo "Add vanity API endpoints - ${API_ENDPOINTS}"
	./catalog-settings/update-vanity-api-endpoints.sh "${API_ENDPOINTS}" "${CATALOG_NAME}" "${ORG_NAME}"
 
	##
	## Create consumer organizations
	##
	for CORG_NAME in $CORG_NAME_LIST; do

		## TODO: Provider user in LDAP
		CORG_OWNER_NAME="${CORG_NAME}-user"

		## 
		## Search for user
		## 
		## echo "Search user ${CORG_OWNER_NAME} in ${USER_REGISTRY_NAME_SLUGIFIED}"
		## SEARCH_RESULTS=$(./user-registries/search.sh  "${CORG_OWNER_NAME}" "${USER_REGISTRY_NAME_SLUGIFIED}" "${ORG_NAME}" "${APIMGR_SERVER}")

		##
		## Create user
		##
		##CORG_OWNER_PASSWORD="Byte2e@t!"
		##CORG_OWNER_FIRSTNAME=$(echo $SEARCH_RESULTS | jq -r .results[0].first_name)
		##CORG_OWNER_LASTNAME=$(echo $SEARCH_RESULTS | jq -r .results[0].last_name)
		##CORG_OWNER_EMAIL=$(echo $SEARCH_RESULTS | jq -r .results[0].email)

		## Retrive owner creds from AWS Secret Manager
		# CORG_OWNER_CREDS_JSON=$(get_username_password "creds/apic/${ORG_NAME}-${CATALOG_NAME}-${CORG_NAME}-owner")
		# CORG_OWNER_NAME=$(echo ${CORG_OWNER_CREDS_JSON} | jq -r .username)
		# CORG_OWNER_PASSWORD=$(echo ${CORG_OWNER_CREDS_JSON} | jq -r .password)
		CORG_OWNER_PASSWORD="Byte2e@t!"
		CORG_OWNER_FIRSTNAME="${CORG_NAME}"
		CORG_OWNER_LASTNAME="Owner"
		CORG_OWNER_EMAIL="${CORG_OWNER_NAME}@${EMAIL_DOMAIN}"
		CATALOG_LUR_NAME="${CATALOG_NAME}-catalog"
		./users/get.sh "${CORG_OWNER_NAME}" "${CATALOG_LUR_NAME}" "${ORG_NAME}" "${APIMGR_SERVER}" > /dev/null 2>&1
		if [ $? -eq 0 ]; then
			echo "Update user [${CORG_OWNER_NAME}] already existing in [${CATALOG_LUR_NAME}]"
		else
			echo "Create user [${CORG_OWNER_NAME}] in [${CATALOG_LUR_NAME}]"
		    ./users/create.sh "${CORG_OWNER_NAME}" "${CORG_OWNER_PASSWORD}" "${CORG_OWNER_FIRSTNAME}" "${CORG_OWNER_LASTNAME}" "${CORG_OWNER_EMAIL}" "${CATALOG_LUR_NAME}" "${ORG_NAME}" "${APIMGR_SERVER}"
		fi
		##
		## Create consumer organization
		## 
		./consumer-orgs/get.sh "${CORG_NAME}" "${CATALOG_NAME}" "${ORG_NAME}" > /dev/null 2>&1
		if [ $? -eq 0 ]; then
			echo "Update consumer org [${CORG_NAME}] in catalog [${CATALOG_NAME}] in organization [${ORG_NAME}]"
			./consumer-orgs/update.sh "${CORG_NAME}" "${CATALOG_NAME}" "${ORG_NAME}" "${CATALOG_LUR_NAME}"
		else
			echo "Create consumer org [${CORG_NAME}] in catalog [${CATALOG_NAME}] in organization [${ORG_NAME}]"
			./consumer-orgs/create.sh "${CORG_NAME}" "${CATALOG_NAME}" "${ORG_NAME}" "${CORG_OWNER_NAME}" "${CATALOG_LUR_NAME}"
		fi

	done

	##
	## Create applications
	## 	
	ASSOCIATED_CORG_NAME_ARRAYLIST=($ASSOCIATED_CORG_NAME_LIST)

	myindex=0
	for APP_NAME in $APP_NAME_LIST; do

		##
		## Create app
		## 
		ASSOCIATED_CORG_NAME="${ASSOCIATED_CORG_NAME_ARRAYLIST[${myindex}]}"
		./apps/get.sh "${APP_NAME}" "${ASSOCIATED_CORG_NAME}" "${CATALOG_NAME}" "${ORG_NAME}" > /dev/null 2>&1
		if [ $? -eq 0 ]; then
			echo "Update app [${APP_NAME}] consumer org [${ASSOCIATED_CORG_NAME}] in catalog [${CATALOG_NAME}] in organization [${ORG_NAME}]"
			./apps/update.sh "${APP_NAME}" "${ASSOCIATED_CORG_NAME}" "${CATALOG_NAME}" "${ORG_NAME}"
		else
			echo "Create app [${APP_NAME}] consumer org [${ASSOCIATED_CORG_NAME}] in catalog [${CATALOG_NAME}] in organization [${ORG_NAME}]"
			./apps/create.sh "${APP_NAME}" "${ASSOCIATED_CORG_NAME}" "${CATALOG_NAME}" "${ORG_NAME}"
		fi

		##
		## Retrieve app credentials from AWS Secret Manager
		## 
		APP_CRED_JSON=$(get_app_credential "creds/apic/${ORG_NAME}-${CATALOG_NAME}-${ASSOCIATED_CORG_NAME}-${APP_NAME}")
		CLIENT_ID=$(echo ${APP_CRED_JSON} | jq -r '.client_id')
		CLIENT_SECRET=$(echo ${APP_CRED_JSON} | jq -r '.client_secret')
		## CLIENT_ID=$(echo $RANDOM | md5 | head -c 32; echo;)
		## CLIENT_SECRET=$(echo $RANDOM | md5 | head -c 32; echo;)

		##
		## Set credentials
		##
		CREDENTIAL_NAME="Credential-for-${APP_NAME}"
		echo "Update credential [${CREDENTIAL_NAME}] for app [${APP_NAME}] consumer org [${ASSOCIATED_CORG_NAME}] in catalog [${CATALOG_NAME}] in organization [${ORG_NAME}]"
		./credentials/update.sh "${CLIENT_ID}" "${CLIENT_SECRET}" "${CREDENTIAL_NAME}" "${APP_NAME}" "${ASSOCIATED_CORG_NAME}" "${CATALOG_NAME}" "${ORG_NAME}"

		echo "Verify credential secret [${CREDENTIAL_NAME}] for app [${APP_NAME}] consumer org [${ASSOCIATED_CORG_NAME}] in catalog [${CATALOG_NAME}] in organization [${ORG_NAME}]"
		./credentials/verify-client-secret.sh "${CLIENT_ID}" "${CLIENT_SECRET}" "${CREDENTIAL_NAME}" "${APP_NAME}" "${ASSOCIATED_CORG_NAME}" "${CATALOG_NAME}" "${ORG_NAME}"

		((myindex++))
	done
done