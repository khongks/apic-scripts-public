#!/bin/bash

. ./env.vars
. ./my-env.vars
. ./my-aws-secretmanager.sh
. ./my-org-members.vars

USER_REGISTRY_NAME_SLUGIFIED=$(echo ${USER_REGISTRY_NAME} | slugify)

##
## Login to API Manager
##
########## TODO: AWS Secret Manager ##########
PROVIDER_REALM="provider/default-idp-2"
OWNER_CREDS_JSON=$(get_username_password "creds/apic/${ORG_NAME}-owner")
OWNER_NAME=$(echo ${OWNER_CREDS_JSON} | jq -r .username)
OWNER_PASSWORD=$(echo ${OWNER_CREDS_JSON} | jq -r .password)
./login-mgr.sh "${OWNER_NAME}" "${OWNER_PASSWORD}" "${PROVIDER_REALM}"

###
# Create organization owner members
###
ORG_MEMBER_NAME_ARRAYLIST=(${ORG_MEMBER_NAME_LIST})
ORG_MEMBER_ROLE_NAME_ARRAYLIST=(${ORG_MEMBER_ROLE_NAME_LIST})
index=0
for ORG_MEMBER_NAME in "${ORG_MEMBER_NAME_ARRAYLIST[@]}"; do

	ORG_MEMBER_ROLE_NAME="${ORG_MEMBER_ROLE_NAME_ARRAYLIST[index]}"
	echo "Create member: ${ORG_MEMBER_NAME} as ${ORG_MEMBER_ROLE_NAME}"
	./members/create.sh "${ORG_MEMBER_NAME}" \
						"${ORG_MEMBER_ROLE_NAME}" \
						"${USER_REGISTRY_NAME_SLUGIFIED}" \
						"${ORG_NAME}" \
						"org" \
						"${APIMGR_SERVER}"
	((++index))
done