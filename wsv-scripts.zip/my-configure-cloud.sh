#!/bin/bash

##
## Set your environment variables
##
. ./env.vars
. ./my-env.vars
. ./my-aws-secretmanager.sh

##
## Login to cloud admin
##
./login-cmc.sh

##
## Configure mail server
##
########## TODO: AWS Secret Manager ##########
# EMAIL_SERVER_USER=
########## TODO: AWS Secret Manager ##########
# EMAIL_SERVER_PASS=
EMAIL_SERVER_NAME_SLUGIFIED=$(echo ${EMAIL_SERVER_NAME} | slugify)
./mail-servers/get.sh ${EMAIL_SERVER_NAME_SLUGIFIED} ${ADMIN_ORG_NAME} > /dev/null 2>&1
if [ $? -eq 0 ]; then
	echo "Update mail-server ${EMAIL_SERVER_NAME}"
	./mail-servers/update.sh "$EMAIL_SERVER_NAME" "$EMAIL_SERVER_HOST" "$EMAIL_SERVER_PORT" "$EMAIL_SERVER_USER" "$EMAIL_SERVER_PASS"
else 
	echo "Create mail-server ${EMAIL_SERVER_NAME}"
	./mail-servers/create.sh "$EMAIL_SERVER_NAME" "$EMAIL_SERVER_HOST" "$EMAIL_SERVER_PORT" "$EMAIL_SERVER_USER" "$EMAIL_SERVER_PASS"
fi

##
## Configure notification
##
EMAIL_SERVER_NAME_SLUGIFIED=$(echo ${EMAIL_SERVER_NAME} | slugify)
./cloud-settings/configure-mail-server.sh "$EMAIL_SENDER_NAME" "$EMAIL_SENDER_ADDRESS" "$EMAIL_SERVER_NAME_SLUGIFIED"

USER_REGISTRY_NAME_SLUGIFIED=$(echo ${USER_REGISTRY_NAME} | slugify)

##
## Create LDAP user registry
##
########## TODO: AWS Secret Manager ##########
# ADMIN_DN=
########## TODO: AWS Secret Manager ##########
# ADMIN_PASSWORD=
# ./user-registries/get.sh "${USER_REGISTRY_NAME_SLUGIFIED}" "${ADMIN_ORG_NAME}" "${CLOUD_ADMIN_SERVER}"
# if [ $? -eq 0 ]; then
# 	./user-registries/update.sh "$USER_REGISTRY_NAME" "$ADMIN_DN" "$ADMIN_PASSWORD" "$BIND_PREFIX" "$BIND_SUFFIX" "$SEARCH_DN_BASE" "$LDAP_ENDPOINT_URL" "$DEF_TLS_CLIENT_PROFILE_NAME" "$DEF_TLS_CLIENT_PROFILE_VERSION" "$ADMIN_ORG_NAME" "${CLOUD_ADMIN_SERVER}"
# else
# 	./user-registries/create.sh "$USER_REGISTRY_NAME" "$ADMIN_DN" "$ADMIN_PASSWORD" "$BIND_PREFIX" "$BIND_SUFFIX" "$SEARCH_DN_BASE" "$LDAP_ENDPOINT_URL" "$DEF_TLS_CLIENT_PROFILE_NAME" "$DEF_TLS_CLIENT_PROFILE_VERSION" "$ADMIN_ORG_NAME" "${CLOUD_ADMIN_SERVER}"
# fi

##
## Create OIDC user registry
## 
./user-registries/get.sh "${USER_REGISTRY_NAME_SLUGIFIED}" "${ADMIN_ORG_NAME}" "${CLOUD_ADMIN_SERVER}" > /dev/null 2>&1
if [ $? -eq 0 ]; then
	echo "User registry ${USER_REGISTRY_NAME_SLUGIFIED} already exist."
else
	echo "Create user registry ${USER_REGISTRY_NAME_SLUGIFIED}."
	./user-registries/create-azure-ad-oidc.sh \
		"${USER_REGISTRY_NAME_SLUGIFIED}" \
		"${AZURE_TENANT_ID}" \
		"${AZURE_AD_CLIENT_ID}" \
		"${AZURE_AD_CLIENT_SECRET}" \
		"${DEF_TLS_CLIENT_PROFILE_NAME}" \
		"${DEF_TLS_CLIENT_PROFILE_VERSION}" \
		"${ADMIN_ORG_NAME}" \
		"${CLOUD_ADMIN_SERVER}"
fi

##
## Add User Registry to Organization default
## 
./user-registry-settings/add-user-registry-to-org.sh "${USER_REGISTRY_NAME_SLUGIFIED}" "${ADMIN_ORG_NAME}"

##
## create TLS keystore and TLS server profile
##
for PREFIX in $TLS_PREFIX_LIST
do
	##
	## Retrieve tls.key and tls.crt from AWS Secret Manager
	##
	get_keystore_certkey "certs/apic/${PREFIX}-keystore"
	KEY_FILE="tls.key"
	CERT_FILE="tls.crt"

	##
	## Create keystore
	##
	KEYSTORE_NAME="${PREFIX}-keystore"
	./keystores/get.sh "${KEYSTORE_NAME}" "${ADMIN_ORG_NAME}" "${CLOUD_ADMIN_SERVER}" > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "Update keystore ${KEYSTORE_NAME}"
		./keystores/update.sh "$KEYSTORE_NAME" "$KEY_FILE" "$CERT_FILE" "$ADMIN_ORG_NAME" "$CLOUD_ADMIN_SERVER"
	else
		echo "Create keystore ${KEYSTORE_NAME}"
		./keystores/create.sh "$KEYSTORE_NAME" "$KEY_FILE" "$CERT_FILE" "$ADMIN_ORG_NAME" "$CLOUD_ADMIN_SERVER"
	fi
	##
	## Create TLS server profile
	##
	TLS_SERVER_PROFILE_NAME="${PREFIX}-server-profile"
	TLS_SERVER_PROFILE_VERSION="1.0.0"
	./tls-server-profiles/get.sh "$TLS_SERVER_PROFILE_NAME" "$TLS_SERVER_PROFILE_VERSION" "$ADMIN_ORG_NAME" "$CLOUD_ADMIN_SERVER" > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "Update tls-server-profile ${TLS_SERVER_PROFILE_NAME}"
		./tls-server-profiles/update.sh "${TLS_SERVER_PROFILE_NAME}" "${TLS_SERVER_PROFILE_VERSION}" "${KEYSTORE_NAME}" "" "${ADMIN_ORG_NAME}" "${CLOUD_ADMIN_SERVER}"
	else
		echo "Create tls-server-profile ${TLS_SERVER_PROFILE_NAME}"
		./tls-server-profiles/create.sh "${TLS_SERVER_PROFILE_NAME}" "${TLS_SERVER_PROFILE_VERSION}" "${KEYSTORE_NAME}" "" "${ADMIN_ORG_NAME}" "${CLOUD_ADMIN_SERVER}"
	fi
done

## 
## Search for user (only LDAP, not for OIDC)
## 
## echo "Search for ${OWNER_NAME} in ${USER_REGISTRY_NAME_SLUGIFIED}"
## SEARCH_RESULTS=$(./user-registries/search.sh  "${OWNER_NAME}" "${USER_REGISTRY_NAME_SLUGIFIED}" "${ADMIN_ORG_NAME}" "${CLOUD_ADMIN_SERVER}")
## echo $SEARCH_RESULTS

##
## LDAP: Create user (OIDC - the user is auto-created when user login first time)
##
## OWNER_FIRSTNAME=$(echo $SEARCH_RESULTS | jq -r .results[0].first_name)
## OWNER_LASTNAME=$(echo $SEARCH_RESULTS | jq -r .results[0].last_name)
## OWNER_EMAIL=$(echo $SEARCH_RESULTS | jq -r .results[0].email)
## echo ".	/users/get.sh ${OWNER_NAME} ${USER_REGISTRY_NAME_SLUGIFIED} ${ADMIN_ORG_NAME} ${CLOUD_ADMIN_SERVER}"
##./users/get.sh "${OWNER_NAME}" "${USER_REGISTRY_NAME_SLUGIFIED}" "${ADMIN_ORG_NAME}" "${CLOUD_ADMIN_SERVER}"
##if [ $? -eq 0 ]; then
##	echo "User [${OWNER_NAME}] already existing in [${USER_REGISTRY_NAME_SLUGIFIED}]"
##else
##	## OWNER_PASSWORD is not needed for LDAP user registry
##	echo "Create user [${OWNER_NAME}] in [${USER_REGISTRY_NAME_SLUGIFIED}]"
##	./users/create.sh ${OWNER_NAME} "" "${OWNER_FIRSTNAME}" "${OWNER_LASTNAME}" "${OWNER_EMAIL}" "${USER_REGISTRY_NAME_SLUGIFIED}" "${CLOUD_ADMIN_SERVER}" "${APIMGR_SERVER}"
##fi

## In CP4I, you need to setup the visibility for api-manager-lur to public
LUR_NAME="api-manager-lur"
./user-registries/set-visibility.sh ${LUR_NAME} "admin" "public" "${CLOUD_ADMIN_SERVER}"

##
## LUR: Create a provider organization owner user
##
OWNER_CREDS_JSON=$(get_username_password "creds/apic/${ORG_NAME}-owner")
OWNER_NAME=$(echo ${OWNER_CREDS_JSON} | jq -r .username)
OWNER_PASSWORD=$(echo ${OWNER_CREDS_JSON} | jq -r .password)
./users/get.sh "${OWNER_NAME}" "${LUR_NAME}" "${ADMIN_ORG_NAME}" "${CLOUD_ADMIN_SERVER}" > /dev/null 2>&1
if [ $? -eq 0 ]; then
	echo "User [${OWNER_NAME}] already exist in [${LUR_NAME}]."
else
	echo "Create user [${OWNER_NAME}] in [${LUR_NAME}]"
	./users/create.sh ${OWNER_NAME} "${OWNER_PASSWORD}" "${OWNER_FIRSTNAME}" "${OWNER_LASTNAME}" "${OWNER_EMAIL}" "${LUR_NAME}" "${ADMIN_ORG_NAME}" "${APIMGR_SERVER}"
fi

##
## Create a provider organization 
##
./orgs/get.sh "${ORG_NAME}"
if [ $? -eq 0 ]; then
	echo "Org ${ORG_NAME} already exist."
else
	echo "Create org ${ORG_NAME}"
	./orgs/create.sh "${ORG_NAME}" "${OWNER_NAME}" "${LUR_NAME}" "${ADMIN_ORG_NAME}"
fi
