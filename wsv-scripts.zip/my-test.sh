. ./my-aws-secretmanager.sh

# get_secret_value "TEST" "client_id"

get_keystore_certkey "certs/apic/wsv-np-test-keystore"

CLIENT_ID_SECRET_JSON=$(get_app_credential "creds/apic/wsv-np-test-test-iop")
CLIENT_ID=$(echo $CLIENT_ID_SECRET_JSON | jq -r .client_id)
CLIENT_SECRET=$(echo $CLIENT_ID_SECRET_JSON | jq -r .client_secret)

echo "CLIENT_ID: $CLIENT_ID"
echo "CLIENT_SECRET: $CLIENT_SECRET"


get_truststore_certs "secret-name" "cert0 cert1 cert2"

get_username_password "secret-name"