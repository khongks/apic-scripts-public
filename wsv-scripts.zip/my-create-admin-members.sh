#!/bin/bash

# wsvnonproduser@khongksgmail.onmicrosoft.com

. ./env.vars
. ./my-env.vars
. ./my-admin-members.vars

##
## Login to cloud admin
##
./login-cmc.sh

USER_REGISTRY_NAME_SLUGIFIED=$(echo ${USER_REGISTRY_NAME} | slugify)

###
# Create organization owner members
###
ADMIN_ORG_MEMBER_NAME_ARRAYLIST=(${ADMIN_ORG_MEMBER_NAME_LIST})
ADMIN_ORG_MEMBER_ROLE_NAME_ARRAYLIST=(${ADMIN_ORG_MEMBER_ROLE_NAME_LIST})
for ADMIN_ORG_MEMBER_NAME in "${ADMIN_ORG_MEMBER_NAME_ARRAYLIST[@]}"; do

	ADMIN_ORG_MEMBER_ROLE_NAME="${ADMIN_ORG_MEMBER_ROLE_NAME_ARRAYLIST[index]}"
	echo "Create member: ${ADMIN_ORG_MEMBER_NAME} as ${ADMIN_ORG_MEMBER_ROLE_NAME}"
	./members/create.sh "${ADMIN_ORG_MEMBER_NAME}" \
						"${ADMIN_ORG_MEMBER_ROLE_NAME}" \
						"${USER_REGISTRY_NAME_SLUGIFIED}" \
						"admin" \
						"org" \
						"${CLOUD_ADMIN_SERVER}"
	((++index))
done