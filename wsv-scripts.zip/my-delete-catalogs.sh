#!/bin/bash

##
## Set your environment variables
##
. ./env.vars
. ./my-env.vars

##
## Login to API Manager
##

ORG_NAME="wsv-np"
OWNER_NAME="wsvnonproduser"
########## TODO: AWS Secret Manager ##########
OWNER_PASSWORD="Byte2e@t!"
PROVIDER_REALM="provider/jump-cloud"
USER_REGISTRY_NAME="jump-cloud"
./login-mgr.sh "$OWNER_NAME" "$OWNER_PASSWORD" "$PROVIDER_REALM"

CATALOG_NAME_LIST="ci1 \
			       dv1 \
			       ps1 \
			       ServiceCatalogue \
			       sv1 \
			       test-catalog \
			       tr2 \
			       ts1 \
			       ts2 \
			       ts3 \
			       ts4 \
			       ts5"

for CATALOG_NAME in $CATALOG_NAME_LIST; do

	index=0
	CORG_NAME_LIST="browser \
					internal \
					medipass \
					salesforce \
					servicevic \
					vlocity \
					westpac"

	for CORG_NAME in $CORG_NAME_LIST; do

		echo "Clear apps in ${CORG_NAME}"
		./apps/clear.sh vlocity ci1 wsv-np

	done

	echo "Clear consumer-orgs in catalog ${CATALOG_NAME}"
	./consumer-orgs/clear.sh ${ORG_NAME} ${CATALOG_NAME}

done

echo "Clear catalogs in org ${ORG_NAME}"
./catalogs/clear.sh ${ORG_NAME}